export type Note = {
    id?: number;
    title?: string;
    content?: string;
    reminderDate?: string;
    category?: number;   
    priority?: string;  
};