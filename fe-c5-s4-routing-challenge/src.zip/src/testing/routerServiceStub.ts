export class RouterServiceStub {
    navigateToNotesView() {
        return Promise.resolve([""]);
      }
}